                        ____       _            _ _       
                       / ___| __ _| | __ ___  _(_) |_ ___ 
                      | |  _ / _` | |/ _` \ \/ / | __/ _ \
                      | |_| | (_| | | (_| |>  <| | ||  __/
                       \____|\__,_|_|\__,_/_/\_\_|\__\___|
                                    Network

If you're reading this, hello! If you're interested in working with resource packs
our sister company Blockception is always looking for talented designers and
creative minds! You can find their website @ https://www.blockception.com/

All media assets within this resource pack are copyright of Blockception Limited

====

Warm Regards,

The Galaxite Team